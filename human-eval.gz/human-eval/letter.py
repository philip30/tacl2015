#!/usr/bin/env python

import sys
from collections import defaultdict

data = defaultdict(lambda:set())

for line in sys.stdin:
    line = line.strip().split()
    data[int(line[0])].add(int(line[1]))

for i, l in data.items():
    print i, ":", len(l)
    for x in sorted(l):
        print "\t",x
