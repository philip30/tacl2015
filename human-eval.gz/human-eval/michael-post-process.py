#!/usr/bin/env python

import sys

for line in sys.stdin:
    line = line.strip()
    
    begin = 0
    
    out_str = ""
    while True:
        try:
            i = line.index("{", begin)
            j = line.index("}", i)
        except:
            out_str += line[begin:].replace('"','').replace(";",',')
            break
        out_str += line[begin:i+1].replace('"','').replace(";",',')

        inside = line[i+1:j]
        out_str += inside
        out_str += "}"
        

        begin = j+1
    print out_str

    
