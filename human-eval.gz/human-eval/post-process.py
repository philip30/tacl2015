#!/usr/bin/env python

import sys
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--input", type=str, required=True)
args = parser.parse_args()

with open(args.input) as inp_file:
    data = list(inp_file)

data_map = {}

i=0
while i < len(data):
    line = data[i].strip()
    number = int(line.split(",")[0])
    l = []
    l.append(",".join([str(number-1)]+line.split(",")[1:]))
    j=i+1
    while j < len(data) and data[j].strip() != ",,,," and len(data[j].strip()) > 0:
        l.append(data[j].strip())
        j+=1
    data_map[number] = l
    i=j
    i+=1

with open(args.input,"w") as out_file:
    for key in sorted(data_map):
        for l in data_map[key]:
            print >> out_file, l
        print >> out_file
